from langchain_openai import ChatOpenAI,OpenAIEmbeddings
import httpx
from dotenv import load_dotenv
import os
load_dotenv()
import tiktoken

tiktoken_cache_dir = "./token"
os.environ["TIKTOKEN_CACHE_DIR"] = tiktoken_cache_dir

client = httpx.Client(verify=False) 
llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model = "azure_ai/genailab-maas-DeepSeek-V3-0324",
    http_client = client,
    api_key=os.environ.get("API_KEY")
)
embeddings = OpenAIEmbeddings(
    base_url="https://genailab.tcs.in",
    model="azure/genailab-maas-text-embedding-3-large",
    api_key="sk-wUl8SvuxtY-BeBa9hkqsng",
    http_client=client
 )
print(llm.invoke("Hello!"))
print(embeddings.embed_query("Hello World!"))