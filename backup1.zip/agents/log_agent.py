# A GOOD PROMPT -- ROLE TASK CONTEXT FORMAT
from langchain.agents import create_agent
from langchain.tools import tool,ToolRuntime
from langchain.agents import AgentState
from typing import Literal,Union,Annotated,List
from collections import defaultdict
from llm import llm,embeddings
import random
from langchain_chroma import Chroma
from langchain.messages import AIMessage, HumanMessage, SystemMessage

vector_store = Chroma(
    collection_name="",
    embedding_function=embeddings,
    persist_directory="./chroma_langchain_db",  # Where to save data locally, remove if not necessary
)


log_loc = defaultdict(lambda: 'C://Users//GenAITVMSEZUSR//Desktop//PJ_Tech//logs//debug.log')
@tool("find_log_location",description="Find the log location for a specific resource")
def find_log_location(resource_name:str)->str:
    """Find the log location for a specific resource."""
    return f"The log files have been located at: {log_loc[resource_name]}"


@tool("log_reader",description="Read the log file and provide a summary")
def log_reader(file_path: str) -> str:
    """Read the contents of a file and return it's summary as a string."""
    try:
        with open(file_path, 'r') as file:
            content = file.read()
        messages = [SystemMessage(content="You are a helpful assistant that analyzes log contents and provide a brief description and key metrics on the content."),
                HumanMessage(content="Content \n\n"+ content + "\n\n Please provide analysis of the content.")]
        return llm.invoke(messages).content
    except Exception as e:
        return str(e)

@tool("retrieve_context", description="Retrieve context for a query")
def retrieve_context(query: str):
    """Retrieve information to help answer a query."""
    retrieved_docs = vector_store.similarity_search(query, k=2)
    serialized = "\n\n".join(
        (f"Source: {doc.metadata}\nContent: {doc.page_content}")
        for doc in retrieved_docs
    )
    return serialized, retrieved_docs

    
System_Prompt = '''
You are a log processing agent who can locate the log files for an api or job.
Your task is to find logs and find the cause of the issue.
Your capabilities include:
1. Locating log files for a given resource.
2. Reading log files and providing analysis on the content.
You should first locate the log files using the find_log_location tool, then read the log files using the log_reader tool, and finally provide your analysis.
Answer Format:

Issues Found: <One liner about the issues found in the system>
Count of Issues: <Number of issues found>
'''
log_processing_agent = create_agent(
    model=llm,
    tools=[find_log_location, log_reader, retrieve_context],
    system_prompt=System_Prompt
)

query = "Found an error in the API 'UserService'. Locate the log files and provide analysis on the issue."
for step in log_processing_agent.stream(
    {"messages": [{"role": "user", "content": query}]}):
    for update in step.values():
        for message in update.get("messages", []):
            message.pretty_print()


