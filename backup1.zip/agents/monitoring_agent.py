# A GOOD PROMPT -- ROLE TASK CONTEXT FORMAT
from langchain.agents import create_agent
from langchain.tools import tool,ToolRuntime
from langchain.agents import AgentState
from typing import Literal,Union,Annotated,List
from collections import defaultdict
from llm import llm
import random
from langchain.messages import AIMessage, HumanMessage, SystemMessage
@tool
def monitor_api(loc:str,requirement:str) -> str:
    """To monitor Infra APIs and check their status"""
    statuses = ["operational", "degraded performance", "partial outage", "major outage"]
    status = random.choice(statuses)
    return f"The API at {loc} is currently experiencing: {status} for requirement: {requirement}."


@tool
def monitor_server(ip_address: str, metric: Literal["CPU", "Memory", "Disk", "Network"]) -> str:
    """To monitor server metrics like CPU, Memory, Disk, Network"""
    usage = random.randint(1, 100)
    return f"The current {metric} usage on server {ip_address} is {usage}%."

SYSTEM_PROMPT = '''
You are an Infra Monitoring Agent.
Your job is to monitor infrastructure components such as APIs and servers.

You are provided with tools to check API statuses, server metrics and analyze the health of the infrastructure.
Your capabilities:
1. You can monitor APIs to check their operational status.
2. You can monitor server metrics like CPU, Memory, Disk, and Network usage.

Answer format:
Current Situation : <brief description of the current infra status>
Urgent Actions Needed : <list of actions that need immediate attention>
List of Recommendations : <list of recommendations to improve infra health>
'''
infra_monitoring_agent = create_agent(
    model=llm,
    tools=[monitor_api, monitor_server],
    system_prompt=SYSTEM_PROMPT
)
query = "Monitor the API at 'https://api.example.com/status' for uptime and check the CPU usage on server"
for step in infra_monitoring_agent.stream(
    {"messages": [{"role": "user", "content": query}]}):
    for update in step.values():
        for message in update.get("messages", []):
            message.pretty_print()



